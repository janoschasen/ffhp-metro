<?php
/*
Plugin Name: RSS Shortcode
Version: 0.2
Plugin URI: http://yoast.com/wordpress/rss-shortcode/
Description: Makes it easy to display an RSS feed on a page
Author: Joost de Valk - Updated by Janosch Asen
Author URI: http://yoast.com/
*/

function yoast_rss_shortcode( $atts ) {
	extract(shortcode_atts(array(  
		"feed" 		=> 'http://www.heise.de/security/news/news-atom.xml',  
		"num" 		=> '5',  
		"excerpt" 	=> true,
		"target"	=> '_blank'
	), $atts));
	require_once(ABSPATH.WPINC.'/rss.php');  
	if ( $feed != "" && $rss = fetch_rss( $feed ) ) {
		$content = '';
		if ( $num !== -1 ) {
			$rss->items = array_slice( $rss->items, 0, $num );
		}
		foreach ( (array) $rss->items as $item ) {
			$content .= '<div class="slide">';
			if ($target != '_self')
				$content .= '<h3><a href="http://www.heise.de/security/news"  title="Heise Security Feed" target="'.esc_attr($target).'">'. esc_html($item['title']) .'</a></h3>';
			else
				$content .= '<a href="http://www.heise.de/security/news" title="Heise Security Feed">'. esc_html($item['title']) .'</a>';
			if ( $excerpt != false && $excerpt != "false") {
				$content .= '<p class="rss_excerpt">'. esc_html($item['summary']) .'</p>';
			}
			$content .= '</div>';
		}
		$content .= '';
	}
	return $content;
}

add_shortcode( 'rss', 'yoast_rss_shortcode' );
?>